import pygame

pygame.init()

# configuracion de pantalla
size = (800, 600)  #
ventana = pygame.display.set_mode(size)
reloj = pygame.time.Clock()

# configurar los colores
# rgb , (0,255) Red=rojo, Green=verde    blue=azul
rojo = (240, 50, 50)
verde = (50, 240, 50)
celeste = (40, 200, 200)
negro = (0, 0, 0)
ventanaAbierta = True

##configuracion de Naves
nave=pygame.image.load("img/nave.png")
naveEnemiga=pygame.image.load("img/nave2.png")
fondo=pygame.image.load("img/fondoEspacio.jpg")
xNave=350
yNave=500
xNave2=350
yNave2=50
velocidad=5

# mostrar Pantalla de Juego
while ventanaAbierta:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            ventanaAbierta = False

    ##eventos del teclado- presiona una tecla
        if event.type ==pygame.KEYDOWN:
            if event.key==pygame.K_LEFT: #si la tecla es izquierda.
                xNave=xNave-20
            if event.key==pygame.K_RIGHT: #si la tela es Derecha
                xNave=xNave+20


    # Codigo para poner un fondo de color.
    ventana.fill(rojo)
    ventana.blit(fondo,(0,0))
    ventana.blit(nave,(xNave,yNave))
    ventana.blit(naveEnemiga, (xNave2,yNave2))

    #####CONTROL DE NAVE ENEMIGA######
    xNave2=xNave2 + velocidad
    if xNave2==0:
        velocidad=velocidad*-1
    if xNave2==750:
        velocidad=velocidad*-1

    # pygame.draw.polygon(ventana, verde,[(412,290),(612,490),(712,320)])
    pygame.display.update()
    reloj.tick(30)

pygame.quit()