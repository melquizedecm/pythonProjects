import pygame

pygame.init()

# configuracion de pantalla
size = (800, 600)  #
ventana = pygame.display.set_mode(size)
reloj = pygame.time.Clock()

# configurar los colores
# rgb , (0,255) Red=rojo, Green=verde    blue=azul
rojo = (240, 50, 50)
verde = (50, 240, 50)
celeste = (40, 200, 200)
negro = (0, 0, 0)


fondo=pygame.image.load("img/BG00.png")
fondo2=pygame.image.load("img/fondo2.jpg")
fondo3=pygame.image.load("img/fondo3.jpg")


fondo=pygame.transform.scale(fondo,(800,600))
letra=pygame.font.Font("LOKICOLA.TTF",40)

ventanaAbierta=True


while ventanaAbierta:
    pantallaInicio = True
    pantallaJuego = True
    pantallaFinal = True
    # mostrar Pantalla de Inicio
    while pantallaInicio:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type ==pygame.KEYDOWN:
                    if event.key ==pygame.K_SPACE:
                        pantallaInicio=False

        # Codigo para poner un fondo de color.
        ventana.fill(verde)
        ventana.blit(fondo,(0,0))
        mensaje=letra.render("Presiona Espacio para continuar",1,negro)
        ventana.blit(mensaje,(150,300))

        # pygame.draw.polygon(ventana, verde,[(412,290),(612,490),(712,320)])
        pygame.display.update()
        reloj.tick(30)

    x = 0
    y = 0
    velocidadX = 20
    velocidadY = 20

    # mostrar Pantalla de Juego
    while pantallaJuego:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type ==pygame.KEYDOWN:
                    if event.key ==pygame.K_SPACE:
                        pantallaJuego=False

        # Codigo para poner un fondo de color.
        ventana.fill(verde)
        ventana.blit(fondo2,(0,0))
        mensaje=letra.render("AQUI VAN TUS CODIGOS DEL JUEGO",1,negro)
        ventana.blit(mensaje,(150,300))

        ######animacion de circulos

        pygame.draw.circle(ventana, rojo, (x + 100, y), 40)
        pygame.draw.circle(ventana, verde, (x, y - 200), 40)
        pygame.draw.circle(ventana, rojo, (x - 200, y), 40)
        pygame.draw.circle(ventana, verde, (x, y + 100), 40)

        x = x + velocidadX
        y = y + velocidadY

        if y > 600:
            # regrese
            velocidadY = velocidadY * -1
        if y <= 0:
            velocidadY = velocidadY * -1

        if x > 800:
            # regresar
            velocidadX = velocidadX * -1
        if x <= 0:
            velocidadX = velocidadX * -1










        pygame.display.update()
        reloj.tick(30)


    # mostrar Pantalla de RECORDS
    while pantallaFinal:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type ==pygame.KEYDOWN:
                    if event.key ==pygame.K_SPACE:
                        pantallaFinal=False

        # Codigo para poner un fondo de color.
        ventana.fill(verde)
        ventana.blit(fondo3,(0,0))
        mensaje=letra.render("RECORDS",1,negro)
        ventana.blit(mensaje,(350,50))

        # pygame.draw.polygon(ventana, verde,[(412,290),(612,490),(712,320)])
        pygame.display.update()
        reloj.tick(30)

