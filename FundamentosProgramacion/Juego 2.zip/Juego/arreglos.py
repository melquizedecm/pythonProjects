numeros=[]

### TRUCO 2. CARGAR VALORES EN MI ARREGLO
for i in range(0,10):
    numeros.append(i)

###TRUCO 1.  COMO RECORRO UN ARREGLO
for num in numeros:
    print (num)

numeros.append(1) #pos 0
numeros.append(2) #pos 1
numeros.append(4)
numeros.append(5) #pos 3
numeros.append(6)
numeros.append(2)
numeros.append(3)
numeros.append(4) #pos 7


for i  in range(0,100,2):
    print (i)